import os

while True:
    os.system('python /home/abolfazl/Desktop/bomber.rubika/bomber.py')



