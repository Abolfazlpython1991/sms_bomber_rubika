from threading import Thread
from pystyle import Col
from colorama import Fore
from typing import Optional, Union

class Handler:
    def __init__(self) -> None:
        self.sms, self.call = [], []
    
    def sms_api(self, func):

        self.sms.append(func)
    
    def send_sms(self, num: str, proxies: Optional[dict] = None,  msg_id_for_edit='', object_guid = None):

        

        threads = [Thread(target=self.launcher, args=[func, num, proxies]) for func in self.sms]
        
        for thread in threads:
            thread.start()
        else:
            for thread in threads:
                thread.join()

    def send_call(self, num: str, proxies: Optional[dict] = None,  msg_id_for_edit='', object_guid = None):


        threads = [Thread(target=self.launcher, args=[func, num, proxies]) for func in self.call]

        for thread in threads:
            thread.start()
        else:
            for thread in threads:
                thread.join()

    def launcher(self, func: callable, num: str, proxies: Union[dict | None]):

        try:
            func(num, proxies)
            print('sent')
        except:
            print('error!')




    def call_api(self, func):
        
        self.call.append(func)

    @property
    def sms_api_count(self):
        return len(self.sms)
    
    @property
    def call_api_count(self):
        return len(self.call)
