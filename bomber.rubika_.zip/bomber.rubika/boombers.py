from bombers.functions import Functions
from threading import Thread


def call(number, count):
    Functions.start(choice='call', number=number, spam_count=count)


def sms(number, count):
    number = str(int(number))
    print('sms to ' + number)
    Functions.start(choice='sms', number=number, spam_count=count)


def casms(number, count):
    Thread(lambda: Functions.start(choice='sms', number=number, spam_count=count)).start()
    Thread(lambda: Functions.start(choice='call', number=number, spam_count=count)).start()


def multi(number, count):
    pass



