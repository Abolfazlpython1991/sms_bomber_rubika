from lib import *
import time
import boombers as sender
from rubika.client import Bot as bot_rubika
from rubpy.client import Client as client_rubpy
from rubpy import filters as filters_rubpy
from rubika.client import filters as filters_rubika
from rubika import Socket


bot_rubpy = client_rubpy('bomber_mohammad')
bot_sock = Socket(auth='yndpfdnlwwaeblmmrvwjygihrruzmxze', 
                  privateKey="eyJ2ZXJzaW9uIjoiNiIsImQiOiItLS0tLUJFR0lOIFJTQSBQUklWQVRFIEtFWS0tLS0tXG5NSUlDV3dJQkFBS0JnSFo2Yzk2TjlmcXAyMmdMNXNqNm9USGRKeElpZ3NiNU0rc3Y5TmNzaXlFYktYdFBkMUViXG5ickl3MndibWFhTllWZkhxTXVGSFVTNWx2WGk5SCtFdlJmVkg3ZWlaNjNGMEdzeDhWSG50WnNDMVhyclZnLy9TXG5lUE1FT3huMkcwY0hRUitqOHZvazcrQktMb3lXSHBYM1l3RHhzbG9zT0QzNTZXZlFkeHVJTytqekFnTUJBQUVDXG5nWUFraS9GaUhYaGJNam8wQmpmU2x6MVNIRjRKQWd4RlJHbjNpbnVFUklGR1hSS1dyeFNuT0VjVlFHelAzQk9LXG5CNTI3V2ZzSDh1L2YyQkp5UkNTcFdlUENNazR4d0NyWUFwR01uT2tvZTlwQ2ppMmVSa3VCWE5aNjJRa2ZycDZJXG56SGduVy93dldsL3A2aVlReC8yV0xKZzlmaHhGaTFhbk1xRUdMTFY5dS8rSEFRSkJBTEhSTklvWTAzN25RNnkzXG5LNHptNFd1dnhYRi9jankzVnNtbGZOT1Q2YUpERXRZS2ExSDdLWTZSclBqLzFEVTNYZ1B2SzZMd1BsOWdpWFVyXG55NmxjK2tNQ1FRQ3FraXEyTmNzU1c0K0VSV2ZYczZqaGllenV5TWx6MGlDS1hQbUhjN2dHZGtCcS9TNmFDQUpIXG42L1RQc1VTNEtVZXNTK1lCbEZuWjJSZTVkbFlJQ1NPUkFrQXIzTFVmRTN5b0l4ZllkTjV6UlVoNXJjUUFlVFdPXG5zSkxoN3NaWjBuU2hKL1p2Z2Vaek5JZE51YlYzUG5QMEpKSTJXanJqV0d1cVR6L1kvVktobG1QTkFrRUFvNVV5XG5xVFRGNElFM0RsK1J5MmhkMm85d1QwRDVFcjYrdm5PVVM3ZExFY2R1MkN5ZitORWRmdVJvRUpldGxBRGkzL2FhXG5TNEYrK2xJZFVweU92WDRtUVFKQUlhQmg3NGR1RzZMVHFyWlNSVWl1UzdBMlloTzEzMzhySkwzMFpYVTF6eExaXG41bHlLelRVeUNXZFJxTUhGYjFuaktrbDk5U1ZuYjFmSlNvRWQyamRtTmc9PVxuLS0tLS1FTkQgUlNBIFBSSVZBVEUgS0VZLS0tLS0ifQ==")
bot = bot_rubika(appName='esi',auth='yndpfdnlwwaeblmmrvwjygihrruzmxze', 
                 privateKey="eyJ2ZXJzaW9uIjoiNiIsImQiOiItLS0tLUJFR0lOIFJTQSBQUklWQVRFIEtFWS0tLS0tXG5NSUlDV3dJQkFBS0JnSFo2Yzk2TjlmcXAyMmdMNXNqNm9USGRKeElpZ3NiNU0rc3Y5TmNzaXlFYktYdFBkMUViXG5ickl3MndibWFhTllWZkhxTXVGSFVTNWx2WGk5SCtFdlJmVkg3ZWlaNjNGMEdzeDhWSG50WnNDMVhyclZnLy9TXG5lUE1FT3huMkcwY0hRUitqOHZvazcrQktMb3lXSHBYM1l3RHhzbG9zT0QzNTZXZlFkeHVJTytqekFnTUJBQUVDXG5nWUFraS9GaUhYaGJNam8wQmpmU2x6MVNIRjRKQWd4RlJHbjNpbnVFUklGR1hSS1dyeFNuT0VjVlFHelAzQk9LXG5CNTI3V2ZzSDh1L2YyQkp5UkNTcFdlUENNazR4d0NyWUFwR01uT2tvZTlwQ2ppMmVSa3VCWE5aNjJRa2ZycDZJXG56SGduVy93dldsL3A2aVlReC8yV0xKZzlmaHhGaTFhbk1xRUdMTFY5dS8rSEFRSkJBTEhSTklvWTAzN25RNnkzXG5LNHptNFd1dnhYRi9jankzVnNtbGZOT1Q2YUpERXRZS2ExSDdLWTZSclBqLzFEVTNYZ1B2SzZMd1BsOWdpWFVyXG55NmxjK2tNQ1FRQ3FraXEyTmNzU1c0K0VSV2ZYczZqaGllenV5TWx6MGlDS1hQbUhjN2dHZGtCcS9TNmFDQUpIXG42L1RQc1VTNEtVZXNTK1lCbEZuWjJSZTVkbFlJQ1NPUkFrQXIzTFVmRTN5b0l4ZllkTjV6UlVoNXJjUUFlVFdPXG5zSkxoN3NaWjBuU2hKL1p2Z2Vaek5JZE51YlYzUG5QMEpKSTJXanJqV0d1cVR6L1kvVktobG1QTkFrRUFvNVV5XG5xVFRGNElFM0RsK1J5MmhkMm85d1QwRDVFcjYrdm5PVVM3ZExFY2R1MkN5ZitORWRmdVJvRUpldGxBRGkzL2FhXG5TNEYrK2xJZFVweU92WDRtUVFKQUlhQmg3NGR1RzZMVHFyWlNSVWl1UzdBMlloTzEzMzhySkwzMFpYVTF6eExaXG41bHlLelRVeUNXZFJxTUhGYjFuaktrbDk5U1ZuYjFmSlNvRWQyamRtTmc9PVxuLS0tLS1FTkQgUlNBIFBSSVZBVEUgS0VZLS0tLS0ifQ==")
freinds = {'u0FxsWj05835a6e46eff8e5ab04e50f5': ('mohammad'),
           'u0YaxU0b107b3cba4fbd25cdc3f03390': ('abolfazl'),
           'u0Go96p0e7d619804ac26855548bfcd5': ('mom2number'),
           'u0FV7Lo0c634dda18b01c8f48f5b46df': ('mammad.sha'),
           'u0GRPom02dd8cf6c5f3b816c80ad224c': ('ali.ezzat'),
           'u0FzQVa0b4aaf8d337451aad9a83ad37': ('Sahand.jah'),
           'u0GPONf09b4b9031068df5b8c55bbb23': ('Hesam')}

commands = ['/multi', '/about', '/hack', '/sms', '/account', '/support', '/events', '/start', '/casms', '/call']

admins = ['g0EIGMR099f2de38ba021427a516cfae', 'u0YaxU0b107b3cba4fbd25cdc3f03390']

white_list = ['9376559007', '09376559007',
              '9354947567', '09354947567',
              '9188165575', '09188165575',
              '9386065093', '09386065093',
              '----------', '------------'
              '9189887859', '09189887859',
              '9388374861', '09388374861',
              '----------', '-----------',
              '9052194772', '09052184772']


for freind in freinds.values():
    try:
        for phone in freind[1]:
            white_list.append(phone)
    except:
        pass
        

def is_int(value):
    if len(value) != len('09376559007'):
        return False
    try:
        int(value)
    except:
        return False
    else:
        return True


def save_log(text, message):
    global freinds
    try:
        text = text.replace('name', freinds[message.object_guid])
    except:
        text = text.replace('name', message.object_guid)
    file = open('logs.txt', 'at')
    file.write(text)
    file.close()


@bot_rubpy.on_message_updates(filters_rubpy.is_private, filters_rubpy.is_text)
def start(message):
    global admins
    if message.object_guid in get_esi_bots_chanel_members():
        try:
            file = open('logs.txt', 'at')
            file.write(f"{freinds[message.object_guid]}:{message.text}=>{time.time()} \n")
            file.close()
        except:
            file = open('logs.txt', 'at')
            file.write(f"{message.object_guid}:{message.text}=>{time.time()} \n")
            file.close()
        else:
            message_tx = message.text
            match message.text:
                case '/sms':
                    message.reply(send_phone_number_text_for_sms)
                case '/call':
                    message.reply(send_phone_number_text_for_call)
                case '/multi':
                    message.reply(send_phone_number_text_for_multi)
                case '/hack':
                    message.reply(hack_)
                case '/casms':
                    message.reply(send_phone_number_text_for_casms)
                case '/about':
                    message.reply(about_)
                case '/account':
                    acc_ = message.object_guid
                    acc_type = 'عادی'
                    works_to_do = 'سه از پنج'
                    end = False
                    while True:
                        if acc_ in get_boughts() and not end:
                            acc_type = 'پریمیوم'
                            message.reply('شما به دلیل خرید اکانت پریمیوم دارید' + '!')
                            end = True
                            break
                        if acc_ in admins and not end:
                            acc_type = 'پریمیوم'
                            message.reply('شما به دلیل ادمین بودن اکانت پریمیوم دارید' + '!')
                            end = True
                            break
                        for fren in freinds.keys():
                            if fren == acc_ and not end:
                                acc_type = 'نیمه پریمیوم'
                                message.reply('شما به دلیل رفاقت با اسی اکانت نیمه پریمیوم دارید' + '!')
                                works_to_do = 'چهار از پنج'
                                end = True
                                break
                        if end:
                            break
                    info_ = get_info_(message.object_guid)
                    if acc_type == 'پریمیوم':
                        works_to_do = 'پنج از پنج'
                    response_ =  'نام و نام خانوادگی' + ':' + ' ' + info_[0] + '\n' + 'نام کاربری' + ':' + ' ' + '@' + info_[1] + '\n' + 'شناسه' + ':' + ' ' + '[' + info_[2] + ']' + '\n' + 'نوع حساب' + ':' + ' ' + acc_type + '\n' + 'دسترسی ها' + ':' + ' ' + works_to_do
                    message.reply(response_)
                case '/start':
                    message.reply(wellcome_text + how_it_work)
                case '/help':
                    message.reply(how_it_work)
                case '/events':
                    message.reply(events_)
            if '/' in message.text and is_int(message_tx.replace('/', '')) and message_tx not in commands:
                if message_tx.replace('/', '') in white_list:
                    message.reply('این شماره توسط ادمین محافظت شده خوشتیپ نمیتونی بهش بمبر بزنی خوشتیپ راستی من اینو به اسی میگم که میخواستی به کی بمبر بزنی')
                    save_log(f"name tryed for sms bomber to {message_tx.replace('/', '')}=>{time.time()} \n", message)
                else:
                    message.reply(f"sending 100 sms to {message_tx.replace('/', '')}")
                    message.reply(sms_is_sending)
                    sender.sms(number=message_tx.replace('/', ''), count=count_of_send)
                    message.reply(sms_sent)

            if '$' in message.text and is_int(message_tx.replace('$', '')) and message_tx not in commands:
                if message_tx.replace('$', '') in white_list:
                    message.reply('این شماره توسط ادمین محافظت شده خوشتیپ نمیتونی بهش بمبر بزنی خوشتیپ راستی من اینو به اسی میگم که میخواستی به کی بمبر بزنی')
                    save_log(f"name tryed for call bomber to {message_tx.replace('$', '')}=>{time.time()} \n", message)
                else:
                    message.reply(f"sending 100 call to {message_tx.replace('$', '')}")
                    message.reply(call_is_sending)
                    sender.call(number=message_tx.replace('$', ''), count=count_of_send)
                    message.reply(call_sent)


            if '*' in message.text and is_int(message_tx.replace('*', '')) and message_tx not in commands:

                """message.reply(f"sending 100 multi panel to {message_tx.replace('*', '')}")
                message.reply(multi_is_sending)
                sender.multi(number=message_tx.replace('*', ''))
                message.reply(multi_sent)"""
                pass


            if '?' in message.text and is_int(message_tx.replace('?', '')) and message_tx not in commands:
                if message_tx.replace('?', '') in white_list:
                    message.reply('این شماره توسط ادمین محافظت شده خوشتیپ نمیتونی بهش بمبر بزنی خوشتیپ راستی من اینو به اسی میگم که میخواستی به کی بمبر بزنی')
                    save_log(f"name tryed for casms bomber to {message_tx.replace('?', '')}=>{time.time()} \n", message)
                else:
                    message.reply(f"sending 100 calls and sms to {message_tx.replace('?', '')}")
                    message.reply(call_is_sending)
                    sender.casms(number=message_tx.replace('?', ''), count=count_of_send)
                    message.reply(call_sent)
            elif message.text == '/support' or message.text == '/Support':
                message.reply(insert_your_sms_for_me)
            elif ('/support' in message.text or '/Support' in message.text) and (message.text != '/support' or message.text != '/Support'):
                sms = (message.text).replace('/support', '')
                sms = sms.replace('/support', '')
                file = open('sms.txt', 'at')
                file.write(f"{freinds[message.object_guid]}:{sms} \n")
                file.close()
                message.reply('پیامت ارسال شد خوشتیپ')
            elif message.text not in commands:
                message_ = (message.text).replace('/', '')
                message_ = message_.replace('?', '')
                message_ = message_.replace('*', '')
                message_ = message_.replace('$', '')
                if not is_int(message_) and message_ not in commands:
                    message.reply('ستون من رباتم ها فقط به دستوراتی که هماهنگ شده جواب میدم خوشتیپ')
                    message.reply(commands_lst)
            elif message.object_guid in admins and '/add_event' in message.text:
                if (message.text).replace('/add_event', ''):
                    file = open('events.txt', 'at')
                    file.write(message.text.replace('/add_event', '') + ' \n')
                    file.close()
                    message.reply('رویداد اضافه شد' + '!')
                else:
                    message.reply('متن نفرستادی ادمین' + '!')
            print(message.object_guid)
    else:
        message.reply(join_our_chanel)


"""@bot_rubpy.on_message_updates(filters_rubpy.is_private, filters_rubpy.is_text)
def reply(message):
    if message.object_guid in get_esi_bots_chanel_members():
        if '/' in message.text:
            match message.text:
                case '/sms':
                    message.reply(send_phone_number_text_for_sms)
                case '/call':
                    message.reply(send_phone_number_text_for_call)
                case '/multi':
                    message.reply(send_phone_number_text_for_multi)
                case '/hack':
                    message.reply(hack_)
                case '/casms':
                    message.reply(send_phone_number_text_for_casms)
                case '/about':
                    message.reply(about_)
                case '/account':
                    message.reply(account_)
                case '/start':
                    message.reply(wellcome_text + how_it_work)
                case '/help':
                    message.reply(how_it_work)
                case '/events':
                    message.reply(events_)
                case _:
                    if (message.text)[0] == '/' and not is_int(message.text[1:-1]):
                        message.reply('command is invalid! دستور پیدا نشد خوشتیپ')
    else:
        message.reply(join_our_chanel)"""


koskhols = open('koskhols.txt', 'rt').read().split('$')
koskhols.pop(-1)


@bot_rubpy.on_message_updates(filters_rubpy.is_group)
def send_response(message):
    if message.object_guid not in admins and '///' in message.text:
        message.reply(f"کصخل تو که ادمین نیستی")
        message.reply(f"شما به لیست کصخل ها اضافه شدی")
        if message.object_guid in koskhols:
            message.reply('البته اضافه نشدی چون از قبل تو این لیست بودی خوشتیپ')
        else:
            file = open('koskhols.txt', 'at')
            file.write(message.object_guid)
            file.close()
    if message.object_guid in admins and '///' in message.text:
        if (message.text).replace('///', '') in white_list:
            message.reply('این شماره محافظت شده است اما یک شما ادمین با دسترسی کامل هستید')
        message.reply(f"😱😱 attack with anythings to {(message.text).replace('///', '')}")
        message.reply(f"it`s very ☠️☠️☠️☠️☠️☠️☠️☠️")
        message.reply(f"sending multi panel to {(message.text).replace('///', '')}")
        message.reply(f"attack rubika account of {(message.text).replace('///', '')}")
        message.reply(f"attack insta account of {(message.text).replace('///', '')}")
        message.reply(f"attack telegram account of {(message.text).replace('///', '')}")
        message.reply(f"attack mobile of {(message.text).replace('///', '')}")
        message.reply(f"attack sms and call to {(message.text).replace('///', '')}")


bot_rubpy.run()


