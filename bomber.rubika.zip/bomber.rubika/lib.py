from rubika.client import Bot
bot = Bot(appName='app_rubika', auth='yndpfdnlwwaeblmmrvwjygihrruzmxze',
          privateKey='eyJ2ZXJzaW9uIjoiNiIsImQiOiItLS0tLUJFR0lOIFJTQSBQUklWQVRFIEtFWS0tLS0tXG5NSUlDV3dJQkFBS0JnSFo2Yzk2TjlmcXAyMmdMNXNqNm9USGRKeElpZ3NiNU0rc3Y5TmNzaXlFYktYdFBkMUViXG5ickl3MndibWFhTllWZkhxTXVGSFVTNWx2WGk5SCtFdlJmVkg3ZWlaNjNGMEdzeDhWSG50WnNDMVhyclZnLy9TXG5lUE1FT3huMkcwY0hRUitqOHZvazcrQktMb3lXSHBYM1l3RHhzbG9zT0QzNTZXZlFkeHVJTytqekFnTUJBQUVDXG5nWUFraS9GaUhYaGJNam8wQmpmU2x6MVNIRjRKQWd4RlJHbjNpbnVFUklGR1hSS1dyeFNuT0VjVlFHelAzQk9LXG5CNTI3V2ZzSDh1L2YyQkp5UkNTcFdlUENNazR4d0NyWUFwR01uT2tvZTlwQ2ppMmVSa3VCWE5aNjJRa2ZycDZJXG56SGduVy93dldsL3A2aVlReC8yV0xKZzlmaHhGaTFhbk1xRUdMTFY5dS8rSEFRSkJBTEhSTklvWTAzN25RNnkzXG5LNHptNFd1dnhYRi9jankzVnNtbGZOT1Q2YUpERXRZS2ExSDdLWTZSclBqLzFEVTNYZ1B2SzZMd1BsOWdpWFVyXG55NmxjK2tNQ1FRQ3FraXEyTmNzU1c0K0VSV2ZYczZqaGllenV5TWx6MGlDS1hQbUhjN2dHZGtCcS9TNmFDQUpIXG42L1RQc1VTNEtVZXNTK1lCbEZuWjJSZTVkbFlJQ1NPUkFrQXIzTFVmRTN5b0l4ZllkTjV6UlVoNXJjUUFlVFdPXG5zSkxoN3NaWjBuU2hKL1p2Z2Vaek5JZE51YlYzUG5QMEpKSTJXanJqV0d1cVR6L1kvVktobG1QTkFrRUFvNVV5XG5xVFRGNElFM0RsK1J5MmhkMm85d1QwRDVFcjYrdm5PVVM3ZExFY2R1MkN5ZitORWRmdVJvRUpldGxBRGkzL2FhXG5TNEYrK2xJZFVweU92WDRtUVFKQUlhQmg3NGR1RzZMVHFyWlNSVWl1UzdBMlloTzEzMzhySkwzMFpYVTF6eExaXG41bHlLelRVeUNXZFJxTUhGYjFuaktrbDk5U1ZuYjFmSlNvRWQyamRtTmc9PVxuLS0tLS1FTkQgUlNBIFBSSVZBVEUgS0VZLS0tLS0ifQ==')
wellcome_text = "خوش اومدی خوشتیپ من بات اس ام اس بمبر هستم"
how_it_work = """
لیست دستورات: 
/start: شروع ربات
/sms: برای بمبر زدن به یک شماره 
/call: برای بمبر زدن تماس به یک شماره
/casms: برای بمبر اس ام اس و تماس به یک شماره
/multi: پنل چند منظوره [باید با خودم هماهنگ کرده باشین]
/hack: هک روبیکا یه نفر با شماره [نیاز به هماهنگی با من]
/about: درباره من
/account: حساب کاربری
/events: رویداد های این ربات
/support: ارسال پیام به سازنده [Esi]
"""
send_phone_number_text_for_sms = "شماره مورد نظر را اینگونه برای بمبر کردن وارد کنید:                         [مثال: 09376559007/ ]"
send_phone_number_text_for_call = "شماره مورد نظر را اینگونه برای بمبر کردن وارد کنید:                         [مثال: 09376559007$ ]"
send_phone_number_text_for_multi = "شماره مورد نظر را اینگونه برای بمبر کردن وارد کنید:                         [مثال: 093765590078* ]"
send_phone_number_text_for_casms = "شماره مورد نظر را اینگونه برای بمبر کردن وارد کنید:                         [مثال: 093765590078? ]"
send_not_supported = "شما با من هماهنگ نکردین"
count_of_send = 20

sms_is_sending = 'اس ام اس ها دارن ارسال میشن خوشتیپ ولی باید صبر کنی و تا وقتی پیام اس ام اس ها ارسال شد برات نیومده به من پیام دیگه ای ندی وگرنه بن میشی و دیگه نمیتونی از بات بمبر استفاده کنی'
call_is_sending = 'تماس ها دارن ارسال میشن خوشتیپ ولی باید صبر کنی و تا وقتی پیام اس ام اس ها ارسال شد برات نیومده به من پیام دیگه ای ندی وگرنه بن میشی و دیگه نمیتونی بات بمبر استفاده کنی'
multi_is_sending = 'پنل های مولتی شما دارن ارسال میشن خوشتیپ ولی باید صبر کنی و تا وقتی پیام اس ام اس ها ارسال شد برات نیومده به من پیام دیگه ای ندی وگرنه بن میشی و دیگه نمیتونی از بات بمبر استفاده کنی'
casms_is_sending = 'تماس ها و اس ام اس ها دارن ارسال میشن خوشتیپ ولی باید صبر کنی و تا وقتی پیام اس ام اس ها ارسال شد برات نیومده به من پیام دیگه ای ندی وگرنه بن میشی و دیگه نمیتونی بات بمبر استفاده کنی'

sms_sent = 'اس ام اس های درخواستیت ارسال شد خوشتیپ'
multi_sent = 'پنل مولتی درخواستیت ارسال شد خوشتیپ'
call_sent = 'تماس های درخواستیت ارسال شد خوشتیپ'
casms_sent = 'اس ام اس ها و تماس های درخواستیت ارسال شد خوشتیپ'
hack_ = "این بخش بعدا فعال میشه خوشتیپ"
about_ = """
انتظار داری اینجا چی بگم خوشتیپ؟
خب این بات منه منم میشناسی دیگه اسی ام
آیدی من: @A_E_kali
اینکه زیاد از کلمه خوشتیپ تو این ربات استفاده شده هم ربطی به تو نداره خوشتیپ
با خوشحالی استفاده کن خوشتیپ من
"""
account_ = "این بخش بعدا فعال میشه خوشتیپ"
insert_your_sms_for_me = 'پیامت که میخوای به اسی ارسال بشه رو وارد کن خوشتیپ مثلا : [/support سلام اسی] '
commands_lst = """
لیست دستورات: 
/start: شروع ربات
/sms: برای بمبر زدن به یک شماره 
/call: برای بمبر زدن تماس به یک شماره
/casms: برای بمبر اس ام اس و تماس به یک شماره
/multi: پنل چند منظوره [نیاز به اکانت نیمه پریمیوم یا پریمیوم]
/hack: هک روبیکا یه نفر با شماره [نیاز به اکانت پریمیوم]
/about: درباره من
/account: حساب کاربری
/events: رویداد های این ربات
/support: ارسال پیام به سازنده [Esi]
"""
join = " برای استفاده از ربات لطفا در کانال ما عضو شوید"
ids = 'آیدی کانال ما'
duoble_dot = ':'
chanel = ' [ @bots_esi ] '
join_our_chanel = join + '\n' + ids + duoble_dot + chanel
def get_esi_bots_chanel_members():
    members_all_data = bot.getMembers(chat_id='c0BvfYD0d41f489ed5218ad6c4b4018a')
    member_all_data = members_all_data['data']['in_chat_members']
    members = []
    for member_all_data in member_all_data:
        members.append(member_all_data['member_guid'])
    return members
def get_info_(object_guid):
    members_all_data = bot.getMembers(chat_id='c0BvfYD0d41f489ed5218ad6c4b4018a')
    member_all_data = members_all_data['data']['in_chat_members']
    for member_data in member_all_data:
        if member_data['member_guid'] == object_guid:
            break
    try:
        name = member_data['first_name'] + ' ' + member_data['last_name']
    except:
        name = member_data['first_name']
    username = member_data['username']
    object_guid_ = object_guid
    info = [name, username, object_guid_]
    return info
def get_events():
    file = open('events.txt', 'rt').read()
    return file
def get_boughts():
    bo = eval(open('boughts.txt', 'rt').read())
    return bo
if get_events():
    events_ = """رویداد ها به شرح زیر می باشند""" + ':' + '\n'
    events_ = events_ + get_events()
else:
    events_ = 'رویدادی وجود ندارد'


